package tile;

import java.awt.image.BufferedImage;

public class Tile {
    BufferedImage image; // Image of the tile
    public boolean collision; // True if the tile is solid
}
