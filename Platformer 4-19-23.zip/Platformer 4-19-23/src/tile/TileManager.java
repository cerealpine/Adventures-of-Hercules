package tile;

import main.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.util.Objects;

public class TileManager {

    GamePanel gp;
    public Tile[] tile; // Array of type Tile containing all the valid tiles
    public int[][][] mapTileNum; // int[i][j][k], i = map number, (j, k) = location of tile
    public int[][] dimensions; // dimensions of the loaded map

    public TileManager(GamePanel gp)
    {
        this.gp = gp;
        tile = new Tile[50];
        mapTileNum = new int[gp.maxMap][gp.maxWorldCol][gp.maxWorldRow];
        dimensions = new int[gp.maxMap][2];
        //dimensions[0] is the num of rows
        //dimensions[1] is the num of columns;

        getTileImage();
        loadMap("/maps/mainMap.txt", 0);
        loadMap("/maps/newMainMap", 1);
    }

    /* Import all tile images*/
    public void getTileImage() {
        setUpTile(0, "/tiles/nothing.png", false);
        setUpTile(1, "/tiles/barrier.png", true);

        //setUpTile(1, "/tiles/grassTemp.png", true);
        //setUpTile(2, "/tiles/brickTemp.png", true);
        setUpTile(10, "/tiles/tileset_forest/tileset_forest_00.png", true);
        setUpTile(11, "/tiles/tileset_forest/tileset_forest_01.png", true);
        setUpTile(12, "/tiles/tileset_forest/tileset_forest_02.png", true);
        setUpTile(13, "/tiles/tileset_forest/tileset_forest_03.png", true);
        setUpTile(14, "/tiles/tileset_forest/tileset_forest_04.png", true);
        setUpTile(15, "/tiles/tileset_forest/tileset_forest_05.png", true);
        setUpTile(16, "/tiles/tileset_forest/tileset_forest_06.png", true);
        setUpTile(17, "/tiles/tileset_forest/tileset_forest_07.png", true);
        setUpTile(18, "/tiles/tileset_forest/tileset_forest_08.png", true);
        setUpTile(19, "/tiles/tileset_forest/tileset_forest_09.png", true);
        setUpTile(20, "/tiles/tileset_forest/tileset_forest_10.png", true);
    }

    /* Processes all tile images */
    public void setUpTile(int index, String imagePath, boolean collision)
    {
        QualityOfLife qol = new QualityOfLife();
        try{
            tile[index] = new Tile();
            tile[index].image = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream(imagePath)));
            tile[index].image = qol.scaleImage(tile[index].image, gp.tileSize, gp.tileSize);
            tile[index].collision = collision;
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    /* Loads a specified map from a text file. Does NOT display it. */
    public void loadMap(String fileName, int mapNum)
    {
        try{
            InputStream is = getClass().getResourceAsStream(fileName);
            BufferedReader br = new BufferedReader( new InputStreamReader( is ));
            String[] dimensionsTemp = br.readLine().split(" ");
            dimensions[mapNum][0] = Integer.parseInt(dimensionsTemp[0]);
            dimensions[mapNum][1] = Integer.parseInt(dimensionsTemp[1]);

            int col = 0;
            int row = 0;

            while(col < dimensions[mapNum][1] && row < dimensions[mapNum][0])
            {
                String line = br.readLine();
                while(col < dimensions[mapNum][1])
                {
                    String[] numbers = line.split(" ");

                    int num = Integer.parseInt(numbers[col]);

                    mapTileNum[mapNum][col][row] = num;
                    col++;
                }
                if(col == dimensions[mapNum][1])
                {
                    col = 0;
                    row++;
                }
            }
            br.close();

        }catch( Exception e ){
            System.err.println("Couldn't find map: " + fileName);
        }
    }

    /* Draws the tiles of the current map to the screen. Only draws the tiles that are visible to the player for
    * performance boost
    */
    public void draw(Graphics2D g2)
    {
        int worldCol = 0;
        int worldRow = 0;

        while(worldCol < dimensions[gp.currentMap][1] && worldRow < dimensions[gp.currentMap][0])
        {
            int tileNum = mapTileNum[gp.currentMap][worldCol][worldRow];

            int worldX = worldCol * gp.tileSize;
            int worldY = worldRow * gp.tileSize;
            int screenX = worldX - gp.player.worldX + gp.player.screenX;
            int screenY = worldY - gp.player.worldY + gp.player.screenY;

            if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
                    worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
                    worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
                    worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
                g2.drawImage(tile[tileNum].image, screenX, screenY,null);
            }
            worldCol++;

            if(worldCol == dimensions[gp.currentMap][1])
            {
                worldCol = 0;
                worldRow++;
            }
        }
    }
}

