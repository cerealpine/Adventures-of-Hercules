package entity;

import main.GamePanel;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Monster extends Entity {

    protected int enemyState;
    protected int walking = 0;
    protected int attacking = 1;
    protected int idle = 2;
    protected int enemyType;
    protected int cAreaXOffset;
    protected int cAreaYOffset;

    protected final int batMonsterType = 0;

    public Monster(GamePanel gp, int x, int y, int width, int height) {
        super(gp);
        this.direction = "left";
        this.enemyState = walking;
        this.worldX = x;
        this.worldY = y;
        isDead = false;
        this.collisionArea.width = width;
        this.collisionArea.height = height;

    }

    public void update() {
        behavior();
        attackPlayer();
        getAttacked();
        spriteCounter++;
        invulnerableCounter++;
        becomeInvulnerable(60);
        /* Counter for animations, cycles from 0 to 4 every 6/60th of a second*/
        if(spriteCounter >= 6) {
            if(spriteNum <= 2)
                spriteNum++;
            else
                spriteNum = 0;
            spriteCounter = 0;
        }

        this.collisionArea.x = screenX;
        this.collisionArea.y = screenY;
    }

    public void draw(Graphics2D g2) {
        //drawHitBox(g2); // For debugging purposes
        gp.dHUD.drawEntityHealthBar(this, g2);
        BufferedImage image = null;

        screenX = worldX - gp.player.worldX + gp.player.screenX;
        screenY = worldY - gp.player.worldY + gp.player.screenY;

        if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
                worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
                worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
                worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {

            if(enemyState == walking){
                image = animationList.get(walking).get(spriteNum);
            } else if(enemyState == attacking) {
                image = animationList.get(attacking).get(spriteNum);
            } else if(enemyState == idle) {
                image = animationList.get(idle).get(spriteNum);
            }

            if(image != null)
            {
                if(direction.equals("right"))
                    g2.drawImage(image,screenX,screenY, null);
                else if(direction.equals("left"))
                    g2.drawImage(image, screenX+image.getWidth(), screenY, -image.getWidth(), image.getHeight(), null);
            }
        }
    }

    protected  void updateYPos(float ySpeed)
    {
        if(gp.collisionHand.checkTile(worldX+cAreaXOffset, worldY+cAreaYOffset + ySpeed, this)) {
            worldY += ySpeed;
        }
    }

    public boolean damagedMelee()
    {
        if(gp.player.isAttacking && gp.player.attackCollisionArea.intersects(this.collisionArea))
        {
            return true;
        }
        return false;
    }

    public void attackPlayer()
    {
        if(this.collisionArea.intersects(gp.player.collisionArea))
            gp.player.damage(attackAmount);
    }

    public void getAttacked()
    {
        if(this.collisionArea.intersects(gp.player.attackCollisionArea)) {
            this.damage(gp.player.attackAmount);
        }
    }

    protected void killEntity() {
        this.isDead = true;
    }
}