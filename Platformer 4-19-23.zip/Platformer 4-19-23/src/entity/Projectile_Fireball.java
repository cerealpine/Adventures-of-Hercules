package entity;

import main.*;

public class Projectile_Fireball extends Projectile{

    public Projectile_Fireball(GamePanel gp)
    {
        super(gp);
        setProjectileFireballImages();

        lifeSpan = 50;
        speed = 5;
        energyCost = 20;
        attackAmount = 50;

        offsetY = -10*gp.scaleTile;
        cAreaXOffset = 0;
        cAreaYOffset = 2*gp.scaleTile;
        collisionArea.x = cAreaXOffset;
        collisionArea.y = cAreaYOffset;
        collisionArea.width = gp.scaleTile*6;
        collisionArea.height = gp.scaleTile*3;
    }

    public void setProjectileFireballImages()
    {
        setup(projectileAnimationList, "/objects/fireball/fireball_0.png", gp.scaleTile*6, gp.scaleTile*6);
        setup(projectileAnimationList, "/objects/fireball/fireball_1.png", gp.scaleTile*6, gp.scaleTile*6);
        setup(projectileAnimationList, "/objects/fireball/fireball_2.png", gp.scaleTile*6, gp.scaleTile*6);
        setup(projectileAnimationList, "/objects/fireball/fireball_3.png", gp.scaleTile*6, gp.scaleTile*6);
    }
}
