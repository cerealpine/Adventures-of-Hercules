package entity;

import main.*;

import java.awt.image.*;

public class Chest extends Object {

    public Chest(GamePanel gp, int x, int y, int width, int height)
    {
        super(gp, x, y, width, height);
        setChestImages();
        objectType = chestType;
        isInteractable = true;

        isOpened = false;
        terminateAnimationTic = 3;
        isActive = true;
        terminateAnimation = false;

        cAreaXOffset = 0;
        cAreaYOffset = 14;
    }

    public void setChestImages()
    {
        setup(idleList, "/objects/chest/object_chest_0.png", gp.tileSize, gp.tileSize);
        setup(idleList, "/objects/chest/object_chest_1.png", gp.tileSize, gp.tileSize);
        setup(idleList, "/objects/chest/object_chest_2.png", gp.tileSize, gp.tileSize);
        setup(idleList, "/objects/chest/object_chest_3.png", gp.tileSize, gp.tileSize);

        animationList.add(idleList);
    }

    public void behavior()
    {
        if(!isOpened) {
            isOpened = true;
        }
    }

    public BufferedImage specialAnimation(BufferedImage image)
    {
        if(isOpened && isActive) {
            spriteNum = 1;
            image = idleList.get(spriteNum);
            isActive = false;
        }else if(isOpened && !isActive && !terminateAnimation)
        {
            image = idleList.get(spriteNum);
            if(spriteNum == terminateAnimationTic) terminateAnimation = true;
        }else if(isOpened && !isActive && terminateAnimation)
            image = idleList.get(terminateAnimationTic);

        return image;
    }
}
