package entity;

import main.*;

import java.awt.Graphics2D;

public class BatMonster extends Monster{


    private String movementDirection = direction;

    int moveDelay = 0;

    public BatMonster(GamePanel gp, int x, int y)
    {
        super(gp, x, y, gp.tileSize, gp.tileSize);
        enemyType = batMonsterType;
        setBatMonsterImages();
        speed = 2;
        attackAmount = 10;
    }

    public void setBatMonsterImages()
    {
        setup(walkList, "/monsters/bat/bat_walk_0.png", gp.tileSize, gp.tileSize);
        setup(walkList, "/monsters/bat/bat_walk_1.png", gp.tileSize, gp.tileSize);
        setup(walkList, "/monsters/bat/bat_walk_2.png", gp.tileSize, gp.tileSize);
        setup(walkList, "/monsters/bat/bat_walk_3.png", gp.tileSize, gp.tileSize);

        animationList.add(walkList);
        animationList.add(attackList);
    }

    public void behavior()
    {
        moveDelay++;

        if(moveDelay >= 60)
        {
            int moveDirec = (int)(Math.random()*4);
            switch (moveDirec) {
                case(0):
                    movementDirection = "left";
                    direction = "left";
                    break;
                case(1):
                    movementDirection = "right";
                    direction = "right";
                    break;
                case (2):
                    movementDirection = "up";
                    break;
                case (3):
                    movementDirection = "down";
                    break;
            }
            moveDelay = 0;
        }

        switch (movementDirection) {
            case ("left"):
                updateXPos(speed);
                break;
            case ("right"):
                updateXPos(-speed);
                break;
            case ("up"):
                updateYPos(-speed);
                break;
            case ("down"):
                updateYPos(speed);
        }
    }
}
