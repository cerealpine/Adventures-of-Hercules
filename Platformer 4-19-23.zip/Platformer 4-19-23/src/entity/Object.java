package entity;


import main.GamePanel;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Object extends Entity{

    public boolean isInteractable;
    public int objectType;
    public final int chestType = 0;

    protected boolean isOpened;
    protected boolean isActive;
    protected boolean terminateAnimation;
    protected int terminateAnimationTic;

    public Object(GamePanel gp, int x, int y, int width, int height)
    {
        super(gp);
        this.direction = "left";
        this.worldX = x;
        this.worldY = y;
        this.objectType = -1;
        this.collisionArea.width = width;
        this.collisionArea.height = height;
    }

    public void update()
    {
        spriteCounter++;
        /* Counter for animations, cycles from 0 to 4 every 6/60th of a second*/
        if(spriteCounter >= 6) {
            if(spriteNum <= 2)
                spriteNum++;
            else
                spriteNum = 0;
            spriteCounter = 0;
        }

        this.collisionArea.x = screenX+cAreaXOffset;
        this.collisionArea.y = screenY+cAreaYOffset;
    }

    public void draw(Graphics2D g2)
    {
        //drawHitBox(g2); // For debugging purposes

        BufferedImage image;

        screenX = worldX - gp.player.worldX + gp.player.screenX;
        screenY = worldY - gp.player.worldY + gp.player.screenY;

        if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
                worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
                worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
                worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {

            image = idleList.get(0);
            image = specialAnimation(image);

            if(image != null)
            {
                if(direction.equals("left"))
                    g2.drawImage(image,screenX,screenY, null);
                else if(direction.equals("right"))
                    g2.drawImage(image, screenX+image.getWidth(), screenY, -image.getWidth(), image.getHeight(), null);
            }
        }
    }

    public BufferedImage specialAnimation(BufferedImage image) {
        System.out.println("No special Animation");
        return image;
    }
}
