package entity;

import main.GamePanel;
import handler.KeyHandler;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.AlphaComposite;
import java.util.*;

public class Player extends Entity{

    private final KeyHandler keyHand;

    // Drawing on screen
    boolean isAttacking;
    boolean isBow;
    boolean idle;

    // For Jumping
    public float airSpeed;
    private float gravity;
    private float jumpSpeed;
    private float fallSpeedAfterCollision;
    private boolean inAir;

    // States for animations
    private int playerState;
    protected ArrayList<BufferedImage> bowList = new ArrayList<>();

    //ticks for animations
    private int attackDelay = 0;
    private int bowDelay = 0;

    // Skin Number
    public int skinNum;
    public final int knightSkin = 0;

    // Player stats
    public int attackAmount;
    public int defenseAmount;
    public float totalEnergy, currentEnergy;
    public int numberOfDeaths;

    //Energy consumed stats
    private final float energyRegenerationAmount = 0.2f;
    private final int attackEnergyAmount = 15;
    private final int bowEnergyAmount = 25;

    //Player Objects
    private Projectile projectile;

    // Attacking Hitbox
    public Rectangle attackCollisionArea = new Rectangle(0, 0, 0, 0);

    public Player(GamePanel gp, KeyHandler keyHand)
    {
        super(gp);
        this.keyHand = keyHand;
        setPlayerStats();
        setPlayerImages();
    }

    // SETTING METHODS
    // Set all initial player stats
    private void setPlayerStats()
    {
        //Player Stats
        totalHealth = 100;
        currentHealth = totalHealth;
        attackAmount = 25;
        defenseAmount = 0;
        totalEnergy = 100;
        currentEnergy = totalEnergy;

        //Player Equipment
        projectile = new Projectile_Fireball(gp);

        //Entity Stats
        speed = 3*gp.scaleTile/5;
        direction = "right";
        isAttacking = false;
        isBow = false;
        idle = false;
        playerState = idleGround;

        // Location on screen
        screenX = gp.panelWidth/2;
        screenY = gp.panelHeight/2;

        // World location
        worldY = 1 * gp.tileSize;
        worldX = 2 * gp.tileSize;

        // HitBox
        cAreaXOffset = 5 *gp.scaleTile/5;
        cAreaYOffset = 8 *gp.scaleTile/5;
        collisionArea.x = screenX + cAreaXOffset;
        collisionArea.y = screenY + cAreaYOffset;
        collisionArea.width = 32;
        collisionArea.height = 39;
        scaleHitboxes(collisionArea);

        // For Jumping
        airSpeed = 0F;
        gravity = 0.035F * gp.scaleTile;
        jumpSpeed = -1f * gp.scaleTile;
        fallSpeedAfterCollision = 0.25f * gp.scaleTile;
        inAir = true;

        // For animations
        skinNum = knightSkin;
    }

    public void setPlayerImages()
    {
        // /folder/player+skinNum/action/folder + skinNum + action + direction + num + png
        // Animations for walking
        setup(walkList,"/player/player0/walk/player0_walk_right_0.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(walkList,"/player/player0/walk/player0_walk_right_1.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(walkList,"/player/player0/walk/player0_walk_right_2.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(walkList,"/player/player0/walk/player0_walk_right_3.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(walkList,"/player/player0/walk/player0_walk_right_4.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        // Animations for idle
        setup(idleList,"/player/player0/idle/player0_idle_right_0.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(idleList,"/player/player0/idle/player0_idle_right_1.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(idleList,"/player/player0/idle/player0_idle_right_2.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(idleList,"/player/player0/idle/player0_idle_right_3.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(idleList,"/player/player0/idle/player0_idle_right_4.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        // Animations for attacking
        setup(attackList,"/player/player0/attack/player0_attack_right_0.png", 48 * gp.scaleTile/5*2, 32 * gp.scaleTile/5*2);
        setup(attackList,"/player/player0/attack/player0_attack_right_1.png", 48 * gp.scaleTile/5*2, 32 * gp.scaleTile/5*2);
        setup(attackList,"/player/player0/attack/player0_attack_right_2.png", 48 * gp.scaleTile/5*2, 32 * gp.scaleTile/5*2);
        setup(attackList,"/player/player0/attack/player0_attack_right_3.png", 48 * gp.scaleTile/5*2, 32 * gp.scaleTile/5*2);
        setup(attackList,"/player/player0/attack/player0_attack_right_4.png", 48 * gp.scaleTile/5*2, 32 * gp.scaleTile/5*2);
        // Animations for jumping
        setup(jumpList,"/player/player0/jump/player0_jump_right_0.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(jumpList,"/player/player0/jump/player0_jump_right_1.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(jumpList,"/player/player0/jump/player0_jump_right_2.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        // Animations for falling
        setup(fallList,"/player/player0/fall/player0_fall_right_0.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(fallList,"/player/player0/fall/player0_fall_right_1.png", 20 * gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        // Animations for bowing
        setup(bowList, "/player/player0/bow/bow_0.png", 20*gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(bowList, "/player/player0/bow/bow_1.png", 20*gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        //setup(bowList, "/player/player0_bow_right/bow_2.png", 20*gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(bowList, "/player/player0/bow/bow_3.png", 20*gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(bowList, "/player/player0/bow/bow_4.png", 20*gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);
        setup(bowList, "/player/player0/bow/bow_5.png", 20*gp.scaleTile/5*2, 24 * gp.scaleTile/5*2);


        animationList.add(walkList);
        animationList.add(idleList);
        animationList.add(attackList);
        animationList.add(jumpList);
        animationList.add(fallList);
        animationList.add(bowList);
    }

    private void setPlayerAttackHitBox()
    {
        if(!isAttacking) {
            attackCollisionArea.x = -1;
            attackCollisionArea.y = -1;
            attackCollisionArea.width = 0;
            attackCollisionArea.height = 0;
            scaleHitboxes(attackCollisionArea);
        }else {
            if(direction.equals("right")) {
                attackCollisionArea.x = screenX + 40*gp.scaleTile/5;
                attackCollisionArea.y = screenY;
                attackCollisionArea.width = 32;
                attackCollisionArea.height = 48;
                scaleHitboxes(attackCollisionArea);
            }else{
                attackCollisionArea.x = screenX - 32*gp.scaleTile/5;
                attackCollisionArea.y = screenY;
                attackCollisionArea.width = 32;
                attackCollisionArea.height = 48;
                scaleHitboxes(attackCollisionArea);
            }
        }
    }

    private void scaleHitboxes(Rectangle rect)
    {
//        rect.x *= gp.scaleTile/5;
//        rect.y *= gp.scaleTile/5;
        rect.width *= gp.scaleTile/5;
        rect.height *= gp.scaleTile/5;
    }

    protected void killEntity()
    {
        setPlayerStats();
        numberOfDeaths++;
        System.out.println("You Died");
    }

    private void changeEnergy(float amtChanged) {
        if(currentEnergy+amtChanged <= 0)
            currentEnergy = 0;
        else if(currentEnergy+amtChanged >= totalEnergy)
            currentEnergy = totalEnergy;
        else
            currentEnergy += amtChanged;
    }

    private boolean hasEnoughEnergy(int energyUsed)
    {
        if(currentEnergy - energyUsed < 0)
            return false;
        else
            return true;
    }
    /* Set the player state in order of precedence for animations. (Attacking is more important than ) */
    private void setPlayerState()
    {
        if(idle)
            playerState = idleGround;
        else if(isBow)
            playerState = bowing;
        else if(isAttacking)
            playerState = attacking;
        else if(inAir) {
            if(airSpeed < 0.1)
                playerState = jumping;
            else if(airSpeed > 2)
                playerState = falling;
        }else
            playerState = walking;
        //printState();
    }

    //DEBUGGING METHODS
    /* Print to stout the state the player is in */
    private void printState()
    {
        if(playerState == attacking)
            System.out.println("attacking");
        else if(playerState == idleGround)
            System.out.println("idle");
        else if(playerState == falling)
            System.out.println("fall");
        else if(playerState == jumping)
            System.out.println("jumping");
        else if(playerState == walking)
            System.out.println("walking");
        else if(playerState == bowing)
            System.out.println("bowing");
    }
    /* Draw both player and player attack hitbox */
    private void drawPlayerHitBox(Graphics g)
    {
        g.setColor(Color.RED);
        g.drawRect(collisionArea.x, collisionArea.y, collisionArea.width, collisionArea.height);
        g.setColor(Color.BLUE);
        g.drawRect(attackCollisionArea.x, attackCollisionArea.y, attackCollisionArea.width, attackCollisionArea.height);
    }

    private void killOptionsPlayer()
    {
        if(worldY >= gp.tileSize*gp.tileMan.dimensions[gp.currentMap][0]) {
            killEntity();
        }
    }

    // UPDATE METHODS
    public void update()
    {
        //printState();
        killOptionsPlayer();
        changeEnergy(energyRegenerationAmount);

        idle = true;
        spriteCounter++; attackDelay++; invulnerableCounter++; bowDelay++;
        becomeInvulnerable(40);
        /* Counter for animations, cycles from 0 to 4 every 6/60th of a second*/
        if(spriteCounter >= 6) {
            if(spriteNum <= 3)
                spriteNum++;
            else
                spriteNum = 0;
            spriteCounter = 0;
        }
        /* Parse Action button inputs */
        if(gp.keyHand.interact)
            gp.collisionHand.checkObjectCollision(this);
        /* Update atk animation/hitbox */
        if(keyHand.attack && !isAttacking && hasEnoughEnergy(attackEnergyAmount)) {
            changeEnergy(-attackEnergyAmount);
            isAttacking = true;
            spriteNum = 1;
            attackDelay = 0;
            setPlayerAttackHitBox();
        }else{
            if(isAttacking && attackDelay >= 30) {
                isAttacking = false;
                setPlayerAttackHitBox();
            }
            setPlayerAttackHitBox();
        }

        if(keyHand.attackBow && !isBow && hasEnoughEnergy(bowEnergyAmount) && projectile.isDead){
            changeEnergy(-bowEnergyAmount);
            if(projectile.isDead) {
                projectile.setProjectile(this, this.collisionArea.width, this.collisionArea.height/2-1* gp.scaleTile);
                gp.projectiles.add(projectile);
            }
            isBow = true;
            spriteNum = 1;
            bowDelay = 0;
        }else{
            if(isBow && bowDelay >= 30)
            {
                isBow = false;
            }
        }

        /* If the player is idle, discontinue the method */
        if(!keyHand.right && !keyHand.left && !keyHand.jump && !inAir && !isAttacking && !isBow) return;

        /* Parse jump key input */
        if(keyHand.jump) {
            if(!inAir) {
                inAir = true;
                airSpeed = jumpSpeed;
            }
        }

        /* Update player's horizontal based on key inputs*/
        float xSpeed = 0;
        if(keyHand.right) {
            direction = "right";
            xSpeed = speed;
        }else if (keyHand.left) {
            direction = "left";
            xSpeed = -speed;
        }

        /* If player walks of a ledge, pull it down*/
        if(!inAir) {
            if(!gp.collisionHand.isEntityOnFloor(worldX+cAreaXOffset,worldY+cAreaYOffset, this))
                inAir = true;
        }
        /* Update player position based on collision */
        if(inAir){
            if(gp.collisionHand.checkTile(worldX+cAreaXOffset,worldY+cAreaYOffset + airSpeed, this)) {
                worldY += airSpeed;
                airSpeed += gravity;
                updateXPos(xSpeed);
            }else{
                if(airSpeed > 0) {
                    inAir = false;
                    airSpeed = 0;
                }else
                    airSpeed = fallSpeedAfterCollision;
                updateXPos(xSpeed);
            }
        }else{
            updateXPos(xSpeed);
        }
        idle = false;
    }

    // DRAWING METHODS
    public void draw(Graphics2D g2)
    {
        setPlayerState();
        //drawPlayerHitBox(g2); // For debugging purposes
        BufferedImage image = null;
        int attackXOffset = 0, attackYOffset = 0;

        for(int i = 0; i <= 4; i++)
        {
            if(spriteNum == i)
            {
                if(playerState == walking)
                    image = animationList.get(walking).get(i);
                else if(playerState == idleGround)
                    image = animationList.get(idleGround).get(i);
                else if(playerState == jumping)
                    image = animationList.get(jumping).get((int)(i/5.0 * 3));
                else if(playerState == falling)
                    image = animationList.get(falling).get((int)(i/5.0 * 2));
                else if(playerState == attacking) {
                    image = animationList.get(attacking).get(i);
                }
                else if(playerState == bowing)
                    image = animationList.get(bowing).get(i);
            }
        }

        float opacity = 0.25f;
        if (this.isInvulnerable) g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));

        if(image != null)
        {
            if(playerState != attacking) {
                if (direction.equals("right"))
                    g2.drawImage(image, screenX, screenY, null);
                else if (direction.equals("left"))
                    g2.drawImage(image, screenX+image.getWidth(), screenY, -image.getWidth(), image.getHeight(), null);
            }
            else {
                    if (direction.equals("right")) {
                        attackXOffset = -10*gp.scaleTile/5;
                        attackYOffset = -16*gp.scaleTile/5;
                        g2.drawImage(image, screenX + attackXOffset, screenY + attackYOffset, null);
                    }
                    else if (direction.equals("left")) {
                        attackXOffset = -44*gp.scaleTile/5;
                        attackYOffset = -16*gp.scaleTile/5;
                        g2.drawImage(image, screenX + attackXOffset + image.getWidth(), screenY + attackYOffset, -image.getWidth(), image.getHeight(), null);
                    }
            }
        }
        if(this.isInvulnerable) g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
    }
}
