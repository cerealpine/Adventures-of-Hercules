package entity;

import main.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.util.*;

/* Parent class for all entities in the game.
 */
public class Entity {
    protected GamePanel gp;

    public float totalHealth = 100, currentHealth; //
    public boolean isInvulnerable = false;

    public int attackAmount;
    public int defenseAmount;

    public int screenX, screenY; // Position on the screen
    public int worldX, worldY; // Where entity is located in the game. (Not on the screen)
    public int speed; // Movement speed of the entity
    public String direction; // Direction entity is facing: "left" or "right"
    public boolean isDead; //Is the entity dead
    protected int spriteCounter = 0; // Used for animations
    protected int spriteNum = 0; // Used for animations
    protected int invulnerableCounter = 0;

    //States
    protected final int walking = 0;
    protected final int idleGround = 1;
    protected final int attacking = 2;
    protected final int jumping = 3;
    protected final int falling = 4;
    protected final int bowing = 5;

    public Rectangle collisionArea = new Rectangle(0, 0, 20*2, 24*2); // Hit box of the entity
    public int cAreaXOffset, cAreaYOffset;

    // Holds an ArrayList of images for certain animations
    protected ArrayList<ArrayList<BufferedImage>> animationList = new ArrayList<>();
    protected ArrayList<BufferedImage> walkList = new ArrayList<>();
    protected ArrayList<BufferedImage> idleList = new ArrayList<>();
    protected ArrayList<BufferedImage> attackList = new ArrayList<>();
    protected ArrayList<BufferedImage> jumpList = new ArrayList<>();
    protected ArrayList<BufferedImage> fallList = new ArrayList<>();

    public Entity(GamePanel gp)
    {
        this.gp = gp;
        currentHealth = totalHealth;
    }
    // Sets up images for animations specifically, i.e. how the image is sorted in an arraylist
    public void setup(ArrayList<BufferedImage> imageList, String imagePath, int width, int height)
    {
        QualityOfLife qol = new QualityOfLife();
        BufferedImage image = null;
        try
        {
            image = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream(imagePath)));
            image = qol.scaleImage(image, width, height);
        }catch(IOException e)
        {
            e.printStackTrace();
        }
        imageList.add(image);
    }

    /* Drawing the HitBox for debugging/visual purposes*/
    public void drawHitBox(Graphics g)
    {
        g.setColor(Color.PINK);
        g.drawRect(collisionArea.x, collisionArea.y, collisionArea.width, collisionArea.height);
    }

    public void damage(int dmgAmount)
    {
        if(!isInvulnerable) {
            isInvulnerable = true;
            if (this.currentHealth - dmgAmount > 0)
                this.currentHealth -= dmgAmount;
            else {
                this.currentHealth = 0;
                killEntity();
            }
            invulnerableCounter = 0;
        }
    }

    public void heal(int healAmount)
    {
        if(this.currentHealth + healAmount <= totalHealth)
            this.currentHealth += healAmount;
        else
            this.currentHealth = healAmount;
    }

    public void incMaxHealth(int incAmount)
    {
        currentHealth += (totalHealth+incAmount)/totalHealth;
        totalHealth += incAmount;
    }

    public void becomeInvulnerable(int invulnerableTime)
    {
        if(this.isInvulnerable) {
            if (this.invulnerableCounter > invulnerableTime) {
                this.isInvulnerable = false;
                this.invulnerableCounter = 0;
            }
        }
    }

    /* If the Entity can move xSpeed pixels without hitting a solid tile, then move it. */
    protected void updateXPos(float xSpeed)
    {
        if(gp.collisionHand.checkTile(worldX+cAreaXOffset + xSpeed,worldY+cAreaYOffset, this)) {
            worldX += xSpeed;
        }
    }

    protected void killEntity() {
        System.out.println("Can't kill");
    }

    public void behavior(){
        System.out.println("No Behavior");
    }
}
