package entity;

import main.*;

public class SpikeMonster extends Monster{

    public SpikeMonster(GamePanel gp, int x, int y, int width, int height) {
        super(gp, x, y, width, height);
        setSpikeImages();
        enemyState =
        speed = 0;
    }

    private void setSpikeImages()
    {
        setup(idleList, "", gp.tileSize, gp.tileSize);
    }

}
