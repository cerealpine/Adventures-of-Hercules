package entity;

import main.*;

import java.awt.*;
import java.awt.image.*;
import java.util.*;

public class Projectile extends Entity {

    protected Entity user;
    protected ArrayList<BufferedImage> projectileAnimationList = new ArrayList<>();
    protected int offsetX = 0;
    protected int offsetY = 0;
    public int energyCost;
    protected int lifeSpan;
    protected int life;

    public Projectile(GamePanel gp) {
        super(gp);
        this.isDead = true;
    }

    public void setProjectile(Entity user, int offsetX, int offsetY)
    {
        this.user = user;
        this.direction = user.direction;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        if(direction.equals("right")) {
            this.worldX = user.worldX + offsetX;
            this.worldY = user.worldY + offsetY;
        }else if(direction.equals("left")) {
            this.worldX = user.worldX + offsetX-user.collisionArea.width-this.collisionArea.width;
            this.worldY = user.worldY + offsetY;
        }
        this.isDead = false;
        this.life = lifeSpan;
    }

    public void update()
    {
        collisionArea.x = screenX+cAreaXOffset;
        collisionArea.y = screenY+cAreaYOffset;

        switch (direction)
        {
            case "left":
                updateXPos(-speed); break;
            case "right":
                updateXPos(speed); break;
        }

        gp.collisionHand.checkMonsterCollision(this);

        life--;
        if(life <= 0)
            isDead = true;

        spriteCounter++;
        if(spriteCounter >= 12)
        {
            if(spriteNum == projectileAnimationList.size()-1){
                spriteNum = 0;
            }else
                spriteNum++;
        }
    }

    public void draw(Graphics2D g2)
    {
        BufferedImage image;
        screenX = worldX - gp.player.worldX + gp.player.screenX;
        screenY = worldY - gp.player.worldY + gp.player.screenY;

        if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
                worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
                worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
                worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
            image = projectileAnimationList.get(spriteNum);
            if(direction.equals("right"))
                g2.drawImage(image, screenX, screenY, null);
            if(direction.equals("left"))
                g2.drawImage(image, screenX+image.getWidth(), screenY,-image.getWidth(), image.getHeight(), null);
        }
        //drawHitBox(g2);
    }
}
