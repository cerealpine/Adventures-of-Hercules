package menu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;

public class TitleMenu extends JPanel {

    public boolean playPressed;
    public boolean controlsPressed;
    private Font pixelMono, pixelSans, pixelSansBold;
    private final int width, height;
    private final int buttonSize = 15, titleSize = 30;
    private Font titleFont, buttonFont;

    public TitleMenu(int width, int height) {
        this.setPreferredSize(new Dimension(width, height));
        this.setLocation(0, 0);
        this.setBackground(Color.YELLOW);
        this.width = width;
        this.height = height;

        playPressed = false;
        controlsPressed = false;

        setLayout(new BorderLayout());
        getFonts();
        setFonts();
        addPanels();
    }

    public void getFonts() {
        InputStream is = getClass().getResourceAsStream("/fonts/PixeloidMono-VGj6x.ttf");
        InputStream is1 = getClass().getResourceAsStream("/fonts/PixeloidSans-JR6qo.ttf");
        InputStream is2 = getClass().getResourceAsStream("/fonts/PixeloidSansBold-GOjpP.ttf");
        try {
            pixelMono = Font.createFont(Font.TRUETYPE_FONT, is);
            pixelSans = Font.createFont(Font.TRUETYPE_FONT, is1);
            pixelSansBold = Font.createFont(Font.TRUETYPE_FONT, is2);

        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
        }
    }

    public void setFonts()
    {
        titleFont = pixelSansBold;
        buttonFont = pixelSans;
    }

    public void addPanels()
    {
        TopPanel top = new TopPanel();
        CentralPanel cp = new CentralPanel();

        this.add(top, BorderLayout.NORTH);
        this.add(cp, BorderLayout.CENTER);
    }
    class TopPanel extends JPanel
    {
        public TopPanel()
        {
            setPreferredSize(new Dimension(1, height/4));
            setLayout(new FlowLayout(FlowLayout.CENTER, 0, 40));
            setBackground(Color.WHITE);
            JLabel title = new JLabel("THE ADVENTURES OF HERACLES");
            title.setHorizontalAlignment(JLabel.CENTER);
            title.setVerticalAlignment(JLabel.BOTTOM);
            title.setFont(titleFont);
            title.setFont(title.getFont().deriveFont(Font.PLAIN, titleSize));

            this.add(title);
        }
    }
    class CentralPanel extends JPanel
    {
        public CentralPanel()
        {
            setBackground(Color.BLACK);
            setPreferredSize(new Dimension(width/3, height));
            setLayout(new FlowLayout(FlowLayout.CENTER, width, 80));

            PlayButtonHandler playButtHand = new PlayButtonHandler();
            JButton playButton = new JButton("PLAY");
            playButton.setFont(buttonFont);
            playButton.setFont(playButton.getFont().deriveFont(Font.PLAIN, buttonSize));
            playButton.addActionListener(playButtHand);
            this.add(playButton);

            ControlsButtonHandler ctrlButtHand = new ControlsButtonHandler();
            JButton controlsButton = new JButton("CONTROLS");
            controlsButton.setFont(buttonFont);
            controlsButton.setFont(controlsButton.getFont().deriveFont(Font.PLAIN, buttonSize));
            controlsButton.addActionListener(ctrlButtHand);
            this.add(controlsButton);
        }
    }

    class PlayButtonHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent evt) {
            playPressed = true;
        }
    }
    class ControlsButtonHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent evt)
        {
            controlsPressed = true;
        }
    }


}
