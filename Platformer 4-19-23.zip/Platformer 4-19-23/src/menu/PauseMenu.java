package menu;

import main.GamePanel;

import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.FontFormatException;
import java.awt.Dimension;

import java.io.InputStream;
import java.io.IOException;

public class PauseMenu extends JPanel {

    private Font pixelMono, pixelSans, pixelSansBold;
    private Font statFont, titleFont;
    private final int statFontSize = 15;
    private final int titleFontSize = 25;
    private GamePanel gp;

    public PauseMenu(GamePanel gp)
    {
        this.gp = gp;
        setBackground(Color.RED);
        setFocusable(true);
        this.addKeyListener(gp.keyHand);
        setLayout(new BorderLayout());
        getFonts();
        setFonts();
        PlayerStatsPanel psp = new PlayerStatsPanel();
        this.add(psp, BorderLayout.CENTER);
        MapSectionPanel msp = new MapSectionPanel();
        this.add(msp, BorderLayout.EAST);
    }

    class PlayerStatsPanel extends JPanel
    {
        JLabel totalHealthLabel;
        JLabel currentHealthLabel;
        JLabel defenseLabel; // dummy
        JLabel attackLabel; // dummy
        JLabel numDeathsLabel;

        public PlayerStatsPanel()
        {
            setBackground(Color.BLUE);
            setLayout(new GridLayout( 6, 1));

            JLabel statTitle = new JLabel("Player Stats: ");
            statTitle.setForeground(Color.BLACK);
            statTitle.setFont(titleFont);
            statTitle.setHorizontalAlignment(JLabel.CENTER);
            this.add(statTitle);

            makeStatLabel(totalHealthLabel, "Total Health", (int)gp.player.totalHealth);
            makeStatLabel(currentHealthLabel, "Current Health", (int)gp.player.currentHealth);
            makeStatLabel(defenseLabel, "Defense", 50);
            makeStatLabel(attackLabel, "Attack", 200);
            makeStatLabel(numDeathsLabel, "Deaths", 0);

        }

        public void makeStatLabel(JLabel label, String name, int stat)
        {
            label = new JLabel(name+": " + stat);
            label.setForeground(Color.GRAY);
            label.setFont(statFont);
            label.setHorizontalAlignment(JLabel.CENTER);
            this.add(label);
        }

    }

    class MapSectionPanel extends JPanel
    {
        public MapSectionPanel()
        {
            setLayout(new BorderLayout());
            setPreferredSize(new Dimension(500, 10));

            JPanel titlePanel = new JPanel();
            titlePanel.setLayout(new FlowLayout(FlowLayout.CENTER));


            JLabel mapTitleLabel = new JLabel("Map");
            mapTitleLabel.setFont(titleFont);

            titlePanel.add(mapTitleLabel);

            this.add(titlePanel, BorderLayout.NORTH);
        }

        class MapsPanel extends JPanel
        {
            public MapsPanel()
            {

            }
        }
    }

    public void getFonts() {
        InputStream is = getClass().getResourceAsStream("/fonts/PixeloidMono-VGj6x.ttf");
        InputStream is1 = getClass().getResourceAsStream("/fonts/PixeloidSans-JR6qo.ttf");
        InputStream is2 = getClass().getResourceAsStream("/fonts/PixeloidSansBold-GOjpP.ttf");
        try {
            pixelMono = Font.createFont(Font.TRUETYPE_FONT, is);
            pixelSans = Font.createFont(Font.TRUETYPE_FONT, is1);
            pixelSansBold = Font.createFont(Font.TRUETYPE_FONT, is2);

        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
        }
    }

    public void setFonts()
    {
        statFont = pixelSans;
        statFont = statFont.deriveFont(Font.PLAIN, statFontSize);
        titleFont = pixelSansBold;
        titleFont = titleFont.deriveFont(Font.PLAIN, titleFontSize);
    }
}
