package main;

import java.awt.*;

import java.io.InputStream;
import java.io.IOException;


public class Dialogue {
    private GamePanel gp;
    private Graphics2D g2;
    //Location of dialogue-window/background
    private int x;
    private int y;
    private int width;
    private int height;
    //Dialogue text
    private String dialogue;
    private Font pixelSans;
    private Font dialogueFont;
    private final int dialogueFontSize = 15;
    //Delay of writing text
    private int lineNum;
    private int dialogueCounter;
    private int letterNumber;
    private final int typeSpeed = 5;
    private final int dialogueXBuffer = 20;
    private final int dialogueYBuffer = 30;
    private final int dialogueLineGap = 30;
    private String[] dialogueArr;

    public Dialogue(GamePanel gp)
    {
        this.gp = gp;
        x = gp.tileSize*1;
        y = gp.tileSize*8;
        width = gp.panelWidth - (gp.tileSize * 2);
        height = gp.tileSize * 3;
        getFonts();
        setFont(pixelSans);
        setDialogue("Howdy!\nHow are you?");
    }

    public void drawDialogue(Graphics2D g2)
    {
        this.g2 = g2;
        dialogueSubWindow();
        dialogueText();
    }

    private void dialogueSubWindow()
    {
        //Background
        Color backgroundColorWindow = new Color(0, 0, 0, 200);
        g2.setColor(backgroundColorWindow);
        g2.fillRoundRect(x, y, width, height, 40, 40);
        //Border
        g2.setColor(Color.WHITE);
        //g2.setStroke(new BasicStroke(2)); ///Change width of border
        g2.drawRoundRect(x, y, width, height, 40, 40);
    }

    private void dialogueText()
    {
        g2.setColor(Color.WHITE);
        g2.setFont(dialogueFont);
        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, dialogueFontSize));

        dialogueCounter++;
        if(dialogueCounter >= typeSpeed) {
            letterNumber++;
            dialogueCounter = 0;
        }

        //Draw all lines already typed immediately
        for(int i = 0; i < lineNum; i++) {
            if(i == dialogueArr.length)
                g2.drawString(dialogueArr[i-1], x+dialogueXBuffer, y+dialogueYBuffer + (i-1)*dialogueLineGap);
            else
                g2.drawString(dialogueArr[i], x+dialogueXBuffer, y+dialogueYBuffer + i*dialogueLineGap);
        }

        //Draw current line letter by letter, to create a typed illusion
        if(lineNum < dialogueArr.length)
        {
            if(letterNumber <= dialogueArr[lineNum].length())
                g2.drawString(dialogueArr[lineNum].substring(0, letterNumber), x+dialogueXBuffer, y+dialogueYBuffer + lineNum*dialogueLineGap);
            else{
                letterNumber = 0;
                lineNum++;
            }
        }


    }

    private void createDialogueArr()
    {
        dialogueArr = dialogue.split("\n");
    }

    public void setDialogue(String dialogue)
    {
        this.dialogue = dialogue;
        createDialogueArr();
    }

    private void setFont(Font font)
    {
        dialogueFont = font;
    }

    private void getFonts() {
        InputStream is = getClass().getResourceAsStream("/fonts/PixeloidSans-JR6qo.ttf");
        try {
            pixelSans = Font.createFont(Font.TRUETYPE_FONT, is);

        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
        }
    }
}
