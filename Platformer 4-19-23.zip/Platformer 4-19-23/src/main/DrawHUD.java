package main;
import entity.Entity;
import java.awt.Graphics2D;
import java.awt.Color;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;


public class DrawHUD {

    private GamePanel gp;
    private Graphics2D g2;
    private Dialogue dialogue;
    private BufferedImage healthBarContainer, healthBarContents;
    private BufferedImage energyBarContainer, energyBarContents;

    public DrawHUD(GamePanel gp)
    {
        this.gp = gp;
        dialogue = new Dialogue(this.gp);
        getIconImages();
    }

    public void draw(Graphics2D g2)
    {
        this.g2 = g2;

        drawHealthBar();
        drawEnergyBar();
        /*if(gp.gameState.equals(gp.dialogueState)) {
            dialogue.drawDialogue(g2);
        }*/
    }

    private BufferedImage getImage(String imagePath, int width, int height) {
        QualityOfLife qol = new QualityOfLife();
        BufferedImage image = null;
        try
        {
            image = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream(imagePath)));
            image = qol.scaleImage(image, width, height);
        }catch(IOException e)
        {
            e.printStackTrace();
        }

        return image;
    }

    private void getIconImages()
    {
        int barWidth, barHeight;
        barWidth = 32; barHeight = 8;
        barWidth *= 0.75; barHeight *= 0.75;
        healthBarContainer = getImage("/icons/healthbar/icon_healthbar0.png", barWidth*gp.scaleTile, barHeight*gp.scaleTile);
        healthBarContents = getImage("/icons/healthbar/icon_healthbar1.png", barWidth*gp.scaleTile, barHeight*gp.scaleTile);
        energyBarContainer = getImage("/icons/energybar/icon_energybar_0.png", barWidth*gp.scaleTile, barHeight*gp.scaleTile);
        energyBarContents = getImage("/icons/energybar/icon_energybar_1.png", barWidth*gp.scaleTile, barHeight*gp.scaleTile);
    }

    private void drawHealthBar()
    {
        double percentFilled = (gp.player.currentHealth + 0.0)/gp.player.totalHealth;
        int xPos = 5, yPos = 5;
        xPos *= gp.scaleTile; yPos *= gp.scaleTile;

        g2.drawImage(healthBarContainer,xPos, yPos, null);
        g2.drawImage( healthBarContents
                , xPos, yPos, xPos+(int)(healthBarContents.getWidth()*percentFilled), yPos+healthBarContents.getHeight()
                ,0, 0, (int)(healthBarContents.getWidth()*percentFilled), healthBarContents.getHeight()
                , null);
    }

    private void drawEnergyBar()
    {
        double percentFilled = (gp.player.currentEnergy + 0.0)/gp.player.totalEnergy;
        int xPos = 5, yPos = 15;
        xPos *= gp.scaleTile; yPos *= gp.scaleTile;

        g2.drawImage(energyBarContainer,xPos, yPos, null);
        g2.drawImage( energyBarContents
                , xPos, yPos, xPos+(int)(energyBarContents.getWidth()*percentFilled), yPos+energyBarContents.getHeight()
                ,0, 0, (int)(energyBarContents.getWidth()*percentFilled), energyBarContents.getHeight()
                , null);
    }

    public void drawEntityHealthBar(Entity entity, Graphics2D g2) {
        float percentFilled = entity.currentHealth/entity.totalHealth;
        int length = entity.collisionArea.width, height= 1;
        int xPos = 0, yPos = 0;

        height *= gp.scaleTile;
        xPos *= gp.scaleTile; yPos *= gp.scaleTile;

        g2.setColor(Color.DARK_GRAY);
        g2.fillRoundRect(xPos+entity.screenX, yPos+entity.screenY, length, height, 5, 5);
        g2.setColor(Color.GREEN);
        g2.fillRoundRect(xPos+entity.screenX, yPos+entity.screenY, (int)(length*percentFilled), height, 5, 5);
    }

}