package main;
import entity.*;
import entity.Object;
import handler.*;
import tile.*;

import java.awt.*;
import java.util.*;
import javax.swing.JPanel;

public class GamePanel extends JPanel{
    public final int defaultTileSize = 8; // ~8 bit square tile as default
    public final int scaleTile = 5; // scales the 16bit tile up/down
    public final int tileSize = defaultTileSize * scaleTile; // ~40 bit tile rescaled
    public final int panelTileWidth = 16; // Game panel width in terms of tiles
    public final int panelTileHeight = 12; // Game panel height in terms of tiles
    public final int panelWidth = tileSize * panelTileWidth; // Game panel width in pixels
    public final int panelHeight = tileSize * panelTileHeight; // Game panel height in pixels

    public final int maxMap = 10; // Maximum number of maps
    public final int maxWorldRow = 50; // Maximum dimensions of a map
    public final int maxWorldCol = 50; // ^
    public int currentMap; // Current map to be loaded to screen
    public final int mainMap = 0; // Map ID of the main map
    public final int newMainMap = 1;

    // Backgrounds
    public int backgroundIndex;
    public final int sandBackground = 0;
    public final int mountainABackground = 1;
    public final int mountainBBackground = 2;
    public final int cloudBackground = 3;
    public final int treeBackground = 4;

    //State
    public String gameState;
    public final String playState = "PLAY";
    public final String dialogueState = "DIALOGUE";

    // HUD
    public DrawHUD dHUD = new DrawHUD(this);

    BackgroundHandler bgHand = new BackgroundHandler(this);
    public KeyHandler keyHand = new KeyHandler(); // Handles all key inputs
    public TileManager tileMan = new TileManager(this); // Handles all tiles
    public CollisionHandler collisionHand = new CollisionHandler(this); // Handles all collisions
    public ObjectHandler objectHandler = new ObjectHandler(this); // Places all mobs/objects

    public Player player = new Player(this, keyHand); // instance of the player class, main player

    // Array of an array of all Monsters for a certain map
    public ArrayList<ArrayList<Monster>> monsters = new ArrayList<>();
    // Array of an array of all Objects for a certain map
    public ArrayList<ArrayList<Object>> objects = new ArrayList<>();
    // ArrayList of projectiles
    public ArrayList<Projectile> projectiles = new ArrayList<>();

    public GamePanel()
    {
        this.setPreferredSize(new Dimension(panelWidth, panelHeight));
        this.setDoubleBuffered(true);
        this.setBackground(Color.BLUE);
        this.setFocusable(true);
        this.addKeyListener(keyHand);
        setLayout(new BorderLayout());
    }

    public void setState(String state)
    {
        this.gameState = state;
    }

    /* Default initial game stats*/
    public void setUpGame()
    {
        currentMap = newMainMap;
        backgroundIndex = mountainBBackground;
        for (int i = 0; i < maxMap; i++) {
            monsters.add(new ArrayList<>());
            objects.add(new ArrayList<>());
        }
        objectHandler.setMonsters();
        objectHandler.setObjects();
    }

    public void swapMap()
    {}

    /* Update the position of everything */
    public void update()
    {
        if(gameState.equals(playState))
        {
            player.update();
            for(int i = 0; i < monsters.get(currentMap).size(); i++) {
                Monster currentMonster = monsters.get(currentMap).get(i);
                if(currentMonster != null) {
                    if(!currentMonster.isDead)
                        currentMonster.update();
                    else
                        monsters.get(currentMap).remove(i);
                }
            }
            for(Object object : objects.get(currentMap)) {
                if(object != null)
                    object.update();
            }
            for(int i = 0; i < projectiles.size(); i++) {
                Projectile currentProjectile = projectiles.get(i);
                if(currentProjectile != null) {
                    if(!currentProjectile.isDead)
                        currentProjectile.update();
                    else
                        projectiles.remove(i);
                }
            }
        }
    }

    /* Draw everything needed to the screen */
    public void paintComponent(Graphics g)
    {
        if(gameState.equals(playState) || gameState.equals(dialogueState)) {
            Graphics2D g2 = (Graphics2D)(g);
            super.paintComponent(g2);
            bgHand.setBackground(g2, backgroundIndex);
            tileMan.draw(g2);
            for(Monster monster : monsters.get(currentMap)) {
                if(monster != null) {
                    monster.draw(g2);
                }
            }
            player.draw(g2);
            for(Object object : objects.get(currentMap)) {
                if (object != null)
                    object.draw(g2);
            }
            for(Projectile projectile : projectiles) {
                if(projectile != null) {
                    projectile.draw(g2);
                }
            }
            dHUD.draw(g2);
        }
    }
}
