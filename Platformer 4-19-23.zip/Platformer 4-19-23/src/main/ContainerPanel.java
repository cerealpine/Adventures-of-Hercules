package main;

import handler.*;
import menu.PauseMenu;
import menu.TitleMenu;

import javax.swing.JPanel;
import java.awt.*;

public class ContainerPanel extends JPanel implements Runnable{

    // Game States
    public String gameState;
    public final String titleState = "MENU";
    public final String playState = "PLAY";
    public final String pauseState = "PAUSE";

    // Menus
    private TitleMenu titleMenu;
    private PauseMenu pauseMenu;
    private final GamePanel gp;

    private Thread gameThread;
    public KeyHandler keyHand;

    // FPS
    public final int FPS = 60; // Frames per second
    //Debugging
    private int debugTimertick;
    private final int debugTickDelay = 30; //Num of frames before the STDOUT output
    private long updateTimeMax; //Max time taken to update a frame from a set of debugTickDelay frames
    private long drawTimeMax; //Max time taken to draw a frame from a set of debugTickDelay frames
    private long totalTimeMax; //Max Total time taken for a frame from a set of debugTickDelay frames

    public ContainerPanel(GamePanel gp) {

        this.setPreferredSize(new Dimension(gp.panelWidth, gp.panelHeight));
        this.setLayout(new CardLayout());

        this.gp = gp;
        this.keyHand = gp.keyHand;
        titleMenu = new TitleMenu(gp.panelWidth, gp.panelHeight);
        pauseMenu = new PauseMenu(gp);

        loadMenus();
        setInitialState();
    }

    // Loads all the used menus
    public void loadMenus()
    {

        titleMenu = new TitleMenu(gp.panelWidth, gp.panelHeight);
        pauseMenu = new PauseMenu(gp);

        this.add(titleMenu, titleState);
        this.add(gp, playState);
        this.add(pauseMenu, pauseState);
    }

    // Sets the intial state of the game
    public void setInitialState()
    {
        gameState = titleState;
    }

    // Sets up the game thread
    public void setUpGameThread()
    {
        gameThread = new Thread(this);
        gameThread.start();
    }


    /* Runs the two methods gp.update() and gp.repaint() every 1/60th of a second.
     * All measurements are used in nanoseconds for precision.
     */
    public void run()
    {
        double intervalTime = 1000000000/FPS;
        long lastTime = System.nanoTime(); long currentTime;
        double difference = 0;
        while(gameThread != null) //Every 1/60th of a second, update the screen and paint it
        {
            currentTime = System.nanoTime();
            difference += (currentTime-lastTime)/intervalTime;
            lastTime = currentTime;

            if(difference >= 1)
            {
                setGameState();
                changePanels();
                long startFrame = System.nanoTime();
                gp.update();
                long afterUpdate = System.nanoTime();
                gp.repaint();
                long afterDrawing = System.nanoTime();
                //displayDurations(startFrame, afterUpdate, afterDrawing);
                difference--;
            }
        }
    }

    /* Calculate efficiency, for Debugging*/
    public void displayDurations(long startTime, long updateTime, long drawTime)
    {
        debugTimertick++;

        long updateDur = (updateTime-startTime); long drawDur = (drawTime-updateTime); long totalDur = (drawTime - startTime);
        updateTimeMax = Math.max(updateDur, updateTimeMax); drawTimeMax = Math.max(drawDur, drawTimeMax); totalTimeMax = Math.max(totalDur, totalTimeMax);

        if(debugTimertick >= debugTickDelay)
        {
            System.out.print("Update: " + updateTimeMax);
            System.out.print("  Draw: " + drawTimeMax);
            System.out.print("  Total: " + totalTimeMax);
            System.out.println("");
            debugTimertick = 0; updateTimeMax = 0; drawTimeMax = 0; totalTimeMax = 0;
        }
    }

    /* Contains all the logic to set the state, send it to Game Panel,
     * and change the screen
     */
    public void setGameState()
    {
        if(titleMenu.playPressed) {
            gameState = playState;
        }
        if(keyHand.pause && gameState.equals(playState)) {
            gameState = pauseState;
        }
        if(gameState.equals(pauseState) && !keyHand.pause) {
            gameState = playState;
        }
        gp.setState(this.gameState);
    }

    /* Change what is displayed on the screen depending on the parameter*/
    public void changePanels()
    {
        if(gameState.equals(playState))
            gp.requestFocusInWindow();
        else if (gameState.equals(titleState))
            titleMenu.requestFocusInWindow();
        else if (gameState.equals(pauseState))
            pauseMenu.requestFocusInWindow();

        ((CardLayout) this.getLayout()).show(this, gameState);
    }
}
