package handler;

import main.*;
import tile.*;

import javax.imageio.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;

public class BackgroundHandler {
    private GamePanel gp;
    private BufferedImage[] backgrounds = new BufferedImage[12];

    public BackgroundHandler(GamePanel gp) {
        this.gp = gp;
        getBackgroundImage();
    }

    public void getBackgroundImage() {
        loadBackground("/backgrounds/sandBackgroundTemp.png", 0);
        loadBackground("/backgrounds/mountains_a.png", 1);
        loadBackground("/backgrounds/mountains_b.png", 2);
        loadBackground("/backgrounds/clouds.png", 3);
        loadBackground("/backgrounds/trees.png", 4);

    }

    public void loadBackground(String imagePath, int index)
    {
        QualityOfLife qol = new QualityOfLife();
        try {
            backgrounds[index] = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream(imagePath)));
            backgrounds[index] = qol.scaleImage(backgrounds[index], gp.panelWidth, gp.panelHeight/2);
        }catch(IOException e) {
            e.printStackTrace();
        }

    }

    public void setBackground(Graphics2D g2, int index)
    {
        int startX = gp.player.worldX/backgrounds[index].getWidth();
        int startY = gp.player.worldY/backgrounds[index].getHeight()-1;
        for (int i = startX-1; i < startX+2; i++) {
                g2.drawImage(backgrounds[index], (int)(-gp.player.worldX*0.5) + backgrounds[index].getWidth()*i, -gp.player.worldY+8*gp.tileSize,null);
        }
    }
}
