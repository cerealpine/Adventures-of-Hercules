package handler;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener{
    public boolean left, right, jump, attack, pause = false, attackBow;
    public boolean interact;

    public void keyPressed(KeyEvent evt){
        int code = evt.getKeyCode();
        if(code == KeyEvent.VK_D)
            right = true;
        else if(code == KeyEvent.VK_A)
            left = true;
        if(code == KeyEvent.VK_W)
            jump = true;
        if(code == KeyEvent.VK_SPACE)
            attack = true;
        if(code == KeyEvent.VK_M)
            pause = !pause;
        if(code == KeyEvent.VK_S)
            interact = true;
        if(code == KeyEvent.VK_Q)
            attackBow = true;
    }

    public void keyReleased(KeyEvent evt){
        int code = evt.getKeyCode();
        if(code == KeyEvent.VK_D)
            right = false;
        else if(code == KeyEvent.VK_A)
            left = false;
        if(code == KeyEvent.VK_W)
            jump = false;
        if(code == KeyEvent.VK_SPACE)
            attack = false;
        if(code == KeyEvent.VK_S)
            interact = false;
        if(code == KeyEvent.VK_Q)
            attackBow = false;
    }

    public void keyTyped(KeyEvent evt){}
}
