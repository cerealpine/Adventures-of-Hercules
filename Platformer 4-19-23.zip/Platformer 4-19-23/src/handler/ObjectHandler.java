package handler;


import entity.*;
import main.*;

public class ObjectHandler {
    private GamePanel gp;
    public ObjectHandler(GamePanel gp)
    {
        this.gp = gp;
    }

    public void setMonsters()
    {
        gp.monsters.get(gp.newMainMap).add(new BatMonster(gp, 4*gp.tileSize, 2*gp.tileSize));
        gp.monsters.get(gp.newMainMap).add(new BatMonster(gp, 1*gp.tileSize, 1*gp.tileSize));
        gp.monsters.get(gp.newMainMap).add(new BatMonster(gp, 3*gp.tileSize, 5*gp.tileSize));
        gp.monsters.get(gp.newMainMap).add(new BatMonster(gp, 10*gp.tileSize, 4*gp.tileSize));
    }

    public void setObjects()
    {
        gp.objects.get(gp.newMainMap).add(new Chest(gp, 3*gp.tileSize, 7*gp.tileSize, 32, 24));
    }
}
