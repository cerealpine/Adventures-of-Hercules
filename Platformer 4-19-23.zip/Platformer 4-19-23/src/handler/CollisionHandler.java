package handler;

import entity.*;
import entity.Object;
import main.GamePanel;

import java.awt.*;

/* Handles all the collisions for the game */
public class CollisionHandler {
    GamePanel gp;

    public CollisionHandler(GamePanel gp) {
        this.gp = gp;
    }

    /* Simple check to see if any of the four corners of the entities hit box are inside a solid tile, given if
     *  an entity is at location (x, y)
     */
    public boolean checkTile(float x, float y, Entity entity) {
        if(!isSolid(x, y))
            if(!isSolid(x+entity.collisionArea.width, y+entity.collisionArea.height))
                if(!isSolid(x+entity.collisionArea.width, y))
                    if(!isSolid(x, y+entity.collisionArea.height))
                        return true;
        return false;
    }

    /* Checks if a tile that contains point (x, y) is solid or not. */
    public boolean isSolid(float x, float y)
    {
        float xIndex = x/gp.tileSize, yIndex = y/gp.tileSize;

        int tileIndex = gp.tileMan.mapTileNum[gp.currentMap][(int)xIndex][(int)yIndex];
        return gp.tileMan.tile[tileIndex].collision;
    }

    /* Checks if a given entity is touching the floor. */
    public boolean isEntityOnFloor(int x, int y, Entity entity)
    {
        if(!isSolid(x, y - entity.collisionArea.height))
            if(!isSolid(x + entity.collisionArea.width, y + entity.collisionArea.height))
                return false;
        return true;
    }

    /* checks if an entity is colliding with an interactable object*/

    public void checkObjectCollision(Entity entity)
    {
        for (int i = 0; i < gp.objects.get(gp.currentMap).size(); i++) {
            if(gp.objects.get(gp.currentMap).get(i).isInteractable)
            {
                if(entity.collisionArea.intersects(gp.objects.get(gp.currentMap).get(i).collisionArea))
                    gp.objects.get(gp.currentMap).get(i).behavior();
            }
        }
    }

    public void checkMonsterCollision(Entity entity)
    {
        for (int i = 0; i < gp.monsters.get(gp.currentMap).size(); i++) {
            if(entity.collisionArea.intersects(gp.monsters.get(gp.currentMap).get(i).collisionArea)) {
                gp.monsters.get(gp.currentMap).get(i).damage(entity.attackAmount);
                if(entity instanceof Projectile) {
                    System.out.println("hit monster");
                    entity.isDead = true;
                }
            }
        }
    }
}